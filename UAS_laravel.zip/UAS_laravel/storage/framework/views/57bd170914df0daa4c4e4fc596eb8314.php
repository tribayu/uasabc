<?php $__env->startSection('main-content'); ?>
<h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Perhitungan Simple Additive Weighting (SAW)')); ?></h1>

<!-- Langkah 1: Menentukan Min/Max -->
<div class="card shadow mb-4">
    <div class="card-header">Menentukan Min/Max</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($kriteria->nama_kriteria); ?> (Min/Max)</th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($minMax[$kriteria->id]['min']); ?> / <?php echo e($minMax[$kriteria->id]['max']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Langkah 2: Normalisasi -->
<div class="card shadow mb-4">
    <div class="card-header">Normalisasi</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Alternatif</th>
                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($kriteria->nama_kriteria); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $alternatifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternatif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($alternatif->nama_alternatif); ?></td>
                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($normalizedValues[$alternatif->id][$kriteria->id]); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Langkah 3: Menghitung Vektor V -->
<div class="card shadow mb-4">
    <div class="card-header">Menghitung Vektor V</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Alternatif</th>
                        <th>Vektor V</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $vektorV; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altId => $nilaiV): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($alternatifs->find($altId)->nama_alternatif); ?></td>
                        <td><?php echo e($nilaiV); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Langkah 4: Perankingan -->
<div class="card shadow mb-4">
    <div class="card-header">Peringkat</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Alternatif</th>
                        <th>Vektor V</th>
                        <th>Ranking</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $rank = 1; ?>
                    <?php $__currentLoopData = $vektorV; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altId => $nilaiV): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($alternatifs->find($altId)->nama_alternatif); ?></td>
                        <td><?php echo e($nilaiV); ?></td>
                        <td><?php echo e($rank++); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UAS_laravel\resources\views/perhitungan/saw.blade.php ENDPATH**/ ?>