<?php $__env->startSection('main-content'); ?>
<h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Perhitungan Weighted Product (WP)')); ?></h1>

<!-- Langkah 1: Menentukan Min/Max -->
<div class="card shadow mb-4">
    <div class="card-header">Menentukan Min/Max</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Kriteria</th>
                        <th>Min</th>
                        <th>Max</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($kriteria->nama_kriteria); ?></td>
                        <?php
                        $nilaiKriteria = $penilaians->where('kriteria_id', $kriteria->id)->pluck('nilai');
                        $min = $nilaiKriteria->min();
                        $max = $nilaiKriteria->max();
                        ?>
                        <td><?php echo e(number_format($min, 4)); ?></td>
                        <td><?php echo e(number_format($max, 4)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Langkah 2: Normalisasi -->
<div class="card shadow mb-4">
    <div class="card-header">Normalisasi</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Alternatif</th>
                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($kriteria->nama_kriteria); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $alternatifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternatif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($alternatif->nama_alternatif); ?></td>
                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $penilaian = $penilaians->where('alternatif_id', $alternatif->id)->where('kriteria_id', $kriteria->id)->first();
                        $nilai = $penilaian ? floatval($penilaian->nilai) : 1.0;
                        $min = $penilaians->where('kriteria_id', $kriteria->id)->pluck('nilai')->min();
                        $max = $penilaians->where('kriteria_id', $kriteria->id)->pluck('nilai')->max();
                        $normalized = $kriteria->jenis_kriteria == 'Cost' ? $min / $nilai : $nilai / $max;
                        ?>
                        <td><?php echo e(number_format($normalized, 4)); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Langkah 3: Menghitung Vektor V -->
<div class="card shadow mb-4">
    <div class="card-header">Menghitung Vektor V</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Alternatif</th>
                        <th>Vektor V</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $vektorV = [];
                    $totalVektorS = 0;
                    ?>
                    <?php $__currentLoopData = $alternatifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternatif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $vektorSAlt = 1.0;
                    foreach ($kriterias as $kriteria) {
                    $penilaian = $penilaians->where('alternatif_id', $alternatif->id)->where('kriteria_id', $kriteria->id)->first();
                    $nilai = $penilaian ? floatval($penilaian->nilai) : 1.0;
                    $min = $penilaians->where('kriteria_id', $kriteria->id)->pluck('nilai')->min();
                    $max = $penilaians->where('kriteria_id', $kriteria->id)->pluck('nilai')->max();
                    $normalized = $kriteria->jenis_kriteria == 'Cost' ? $min / $nilai : $nilai / $max;
                    $bobotNormalized = floatval($kriteria->bobot_normalized);

                    $vektorSAlt *= pow($normalized, $bobotNormalized);
                    }
                    $vektorV[$alternatif->id] = $vektorSAlt;
                    $totalVektorS += $vektorSAlt;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $vektorV; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altId => $nilaiS): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($alternatifs->find($altId)->nama_alternatif); ?></td>
                        <td><?php echo e(number_format($nilaiS / $totalVektorS, 4)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Langkah 4: Perankingan -->
<div class="card shadow mb-4">
    <div class="card-header">Peringkat</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Alternatif</th>
                        <th>Vektor V</th>
                        <th>Ranking</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    arsort($vektorV);
                    $rank = 1;
                    ?>
                    <?php $__currentLoopData = $vektorV; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altId => $nilaiV): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($alternatifs->find($altId)->nama_alternatif); ?></td>
                        <td><?php echo e(number_format($nilaiV, 4)); ?></td>
                        <td><?php echo e($rank++); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UAS_laravel\resources\views/perhitungan/wp.blade.php ENDPATH**/ ?>